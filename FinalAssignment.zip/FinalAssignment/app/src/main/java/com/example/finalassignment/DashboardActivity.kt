package com.example.finalassignment

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Get the keypass from the intent
        val keypass = intent.getStringExtra("dashboard") ?: "No keypass received"

        // Display the keypass in a TextView (ensure you have a TextView with id tvKeypass in activity_dashboard layout)
        val keypassTextView = findViewById<TextView>(R.id.tvKeypass)
        keypassTextView.text = "Welcome to Job Searching Dashboard: "
    }
}
