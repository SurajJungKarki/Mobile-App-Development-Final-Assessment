package com.example.finalassignment

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    // Ensure that your base URL ends with a trailing slash
    private const val BASE_URL = "https://jsonplaceholder.typicode.com/"

    // Initialize the Retrofit instance
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)  // Use the BASE_URL constant
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // Function to get the Retrofit instance
    fun getRetrofitInstance(): Retrofit {
        return retrofit
    }
}
