package com.example.finalassignment

data class LoginResponse(
    val keypass: String? // Optional if you want to allow null values
)
