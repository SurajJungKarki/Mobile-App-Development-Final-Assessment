package com.example.finalassignment

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("login") // Replace "login" with your actual login endpoint
    fun login(@Body loginRequest: LoginRequest): Call<LoginResponse>
}
