package com.example.finalassignment

data class LoginRequest(
    val username: String,
    val password: String
)
